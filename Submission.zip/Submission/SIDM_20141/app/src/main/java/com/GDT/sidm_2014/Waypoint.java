package com.GDT.sidm_2014;

/**
 * Created by Seventh on 13/12/2014.
 */
public class Waypoint {
    Vector2D currentPoint;
    Waypoint  nextPoint;
}
