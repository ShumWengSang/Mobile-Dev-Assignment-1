package com.GDT.sidm_2014;

/**
 * Created by Shum on 10/12/2014.
 */
public class Rock extends Entity {
    void update()
    {
        EntityUpdate();
    }
}
