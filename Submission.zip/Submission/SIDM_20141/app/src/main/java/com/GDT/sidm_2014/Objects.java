package com.GDT.sidm_2014;

/**
 * Created by Shum on 14/12/2014.
 */
public enum Objects {
    Player,
    Pirates,
    Cannonballs
}
