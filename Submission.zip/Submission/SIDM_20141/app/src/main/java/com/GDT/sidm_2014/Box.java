package com.GDT.sidm_2014;

public class Box {
	public float x;
	float y;
	float height;
	float width;
	public Box (float x, float y, float height, float width)
	{
		this.x = x;
		this.y = y;
		this.height = height;
		this.width = width;
	}

}
